class IntentEngine:


    def detect(self, message):

        text = message.lower()


        # Comparison questions

        if any(word in text for word in [
            "compare",
            "difference",
            "vs",
            "versus"
        ]):

            return "comparison"



        # Explanation questions

        if any(word in text for word in [
            "explain",
            "describe",
            "teach",
            "simplify"
        ]):

            return "explanation"



        # Why questions

        if text.startswith("why"):

            return "reason"



        # How questions

        if text.startswith("how"):

            return "process"



        # Examples

        if "example" in text:

            return "examples"



        # Functions

        if any(word in text for word in [
            "function",
            "functions",
            "do",
            "work",
            "use"
        ]):

            return "functions"



        # Definition

        if any(word in text for word in [
            "what is",
            "what are",
            "define",
            "meaning"
        ]):

            return "definition"



        return "general"
