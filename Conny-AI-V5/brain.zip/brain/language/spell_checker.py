import difflib

from knowledge.knowledge_engine import KnowledgeEngine


class SpellChecker:

    def __init__(self):

        knowledge = KnowledgeEngine()

        self.dictionary = knowledge.get_all_keywords()

    def correct_word(self, word):

        matches = difflib.get_close_matches(

            word.lower(),

            self.dictionary,

            n=1,

            cutoff=0.70

        )

        if matches:

            return matches[0]

        return word

    def correct_sentence(self, sentence):

        words = sentence.split()

        corrected = []

        for word in words:

            corrected.append(
                self.correct_word(word)
            )

        return " ".join(corrected)
