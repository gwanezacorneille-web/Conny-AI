from brain.responses import ResponseGenerator
from brain.conversation import Conversation
from brain.personality import Personality
from brain.reasoning import Reasoning
from brain.intent_router import IntentRouter

from brain.language.language_engine import LanguageEngine

from knowledge.knowledge_engine import KnowledgeEngine

from memory.memory import Memory

from plugins.plugin_manager import PluginManager
from plugins.plugin_loader import PluginLoader



class Brain:


    def __init__(self):

        self.response = ResponseGenerator()

        self.conversation = Conversation()

        self.personality = Personality()

        self.reasoning = Reasoning()

        self.memory = Memory()

        self.router = IntentRouter()


        # Intelligence layers

        self.language = LanguageEngine()

        self.knowledge = KnowledgeEngine()



        # Plugin System

        self.plugins = PluginManager()

        self.loader = PluginLoader()


        loaded_plugins = self.loader.load_plugins()


        for plugin in loaded_plugins:

            self.plugins.register(plugin)




    def process(self, message):


        self.conversation.add(
            "User",
            message
        )


        # Language understanding

        language_data = self.language.understand(
            message
        )


        corrected_message = language_data["corrected"]



        # Plugins first

        plugin = self.plugins.find_plugin(
            corrected_message
        )


        if plugin:


            answer = plugin.run(
                corrected_message
            )


            self.conversation.add(
                "Conny",
                answer
            )


            return answer




        # Knowledge engine

        knowledge_answer = self.knowledge.search(
            corrected_message
        )


	print("DEBUG corrected:", corrected_message)
	print("DEBUG knowledge:", knowledge_answer)



        if knowledge_answer:


            self.conversation.add(
                "Conny",
                knowledge_answer
            )


            return knowledge_answer




        # Intent detection

        intent = self.router.detect(
            corrected_message
        )



        if intent == "remember":


            information = corrected_message.lower().replace(
                "remember",
                "",
                1
            ).strip()


            self.memory.remember(
                "fact",
                "general",
                information
            )


            answer = "I will remember that."



        elif intent == "favorite_language":


            language = corrected_message.lower().split(
                "is",
                1
            )[1].strip()


            self.memory.remember(
                "preference",
                "favorite_language",
                language
            )


            answer = (
                f"I will remember that your favorite language is {language}."
            )



        elif intent == "study":


            subject = corrected_message.lower().replace(
                "i study",
                "",
                1
            ).strip()


            self.memory.remember(
                "education",
                "study",
                subject
            )


            answer = (
                f"I will remember that you study {subject}."
            )



        elif intent == "recall":


            memories = self.memory.recall()


            answer = "I remember:\n"


            for item in memories:

                answer += (
                    f"- {item[1]}: {item[2]}\n"
                )



        elif intent == "identity":


            answer = (
                "I am Conny AI V5.0, "
                "created by Gwaneza Corneille Karenzi."
            )



        elif intent == "greeting":


            answer = self.response.greeting()



        else:


            answer = self.response.unknown_response()



        self.conversation.add(
            "Conny",
            answer
        )


        return answer
