kfrom brain.responses import ResponseGenerator
from brain.emotion_engine import EmotionEngine
from brain.conversation import Conversation
from brain.personality import Personality
from brain.reasoning import Reasoning
from brain.intent_router import IntentRouter
from brain.intent_engine import IntentEngine
from brain.decision_engine import DecisionEngine

from brain.language.language_engine import LanguageEngine
from brain.router import Router

from knowledge.knowledge_engine import KnowledgeEngine
from memory.memory import Memory

from plugins.plugin_manager import PluginManager
from plugins.plugin_loader import PluginLoader

from learning.learning_engine import LearningEngine


class Brain:

    def __init__(self):

        # Core systems
        self.response = ResponseGenerator()
        self.conversation = Conversation()
        self.personality = Personality()
        self.reasoning = Reasoning()
        self.memory = Memory()

        # Emotion
        self.emotion = EmotionEngine()

        # Learning
        self.learning = LearningEngine()

        # Intent
        self.router = IntentRouter()
        self.intent_engine = IntentEngine()
        self.decision = DecisionEngine()

        # Language
        self.language = LanguageEngine()

        # Knowledge
        self.knowledge = KnowledgeEngine()

        # Plugins
        self.plugins = PluginManager()
        self.loader = PluginLoader()

        for plugin in self.loader.load_plugins():
            self.plugins.register(plugin)

        # Main Router
        self.request_router = Router(self)

    def process(self, message):

        text = message.strip()
        lower = text.lower()

        # =====================================
        # LEARNING MODE
        # =====================================

        if (
            lower.startswith("study ")
            or lower.startswith("teach ")
            or lower.startswith("learn ")
        ):

            subject = text.split(" ", 1)[1]
            return self.learning.start_learning(subject)

        if self.learning.teacher.session.active:

            result = self.learning.process_input(text)

            if result is None:
                return "Lesson received..."

            if result["type"] == "lesson_complete":

                knowledge = result["knowledge"]

                return (
                    "\n"
                    "==============================\n"
                    "Learning Complete\n"
                    "==============================\n\n"
                    f"Topic:\n{knowledge.topic}\n\n"
                    f"Facts found:\n{len(knowledge.facts)}\n\n"
                    f"Keywords found:\n{len(knowledge.keywords)}\n\n"
                    "Knowledge extracted successfully.\n"
                    "Ready for storage."
                )

            return "Lesson received..."

        # =====================================
        # NORMAL CONVERSATION
        # =====================================

        self.conversation.add("User", message)

        # Language understanding
        language = self.language.understand(message)
        corrected = language["corrected"]

        # Intent
        intent = self.intent_engine.detect(corrected)

        # Emotion
        emotion = self.emotion.detect(corrected)

        print("DEBUG Intent:", intent)
        print("DEBUG Emotion:", emotion)

        # Route request
        answer = self.request_router.route(
            corrected,
            emotion=emotion,
            intent=intent
        )

        self.conversation.add("Conny", answer)

        return answer
