class DecisionEngine:
    """
    CONNY AI Advanced Decision Engine

    Responsible for deciding:
    - what the user wants
    - which subsystem should answer
    """

    def __init__(self):

        self.intents = {

            "conversation": [
                "hi",
                "hello",
                "hey",
                "how are you",
                "who are you",
                "your name",
                "thank you",
                "bye"
            ],

            "memory_store": [
                "remember",
                "save this",
                "store this",
                "my favorite",
                "my name is"
            ],

            "memory_recall": [
                "what do you remember",
                "show memories",
                "what do you know about me"
            ],

            "calculator": [
                "calculate",
                "solve",
                "what is",
            ],

            "comparison": [
                "compare",
                "difference between",
                " vs ",
                " versus "
            ],

            "coding": [
                "python",
                "java",
                "javascript",
                "code",
                "program",
                "bug",
                "error",
                "function"
            ],

            "creative": [
                "write",
                "create",
                "story",
                "poem",
                "design",
                "idea"
            ],

            "system": [
                "open",
                "launch",
                "install",
                "remove",
                "run"
            ],

            "internet": [
                "latest",
                "today",
                "current",
                "news",
                "weather",
                "price",
                "score"
            ],

            "knowledge": [
                "what is",
                "who is",
                "why",
                "how",
                "explain",
                "define",
                "meaning"
            ]
        }


    def choose(self, message):

        text = message.lower().strip()


        if not text:
            return "conversation"


        scores = {}


        # Score every possible intent

        for intent, keywords in self.intents.items():

            score = 0

            for word in keywords:

                if word in text:

                    score += 1


            scores[intent] = score



        # Special intelligence rules


        # Greetings should override everything

        if text in [
            "hi",
            "hello",
            "hey"
        ]:

            return "conversation"



        # Memory always has priority

        if text.startswith(
            (
                "remember",
                "save",
                "store"
            )
        ):

            return "memory_store"



        # Comparisons are strong signals

        if (
            " vs " in text
            or
            " versus " in text
            or
            "compare" in text
        ):

            return "comparison"



        # Choose highest score

        best = max(
            scores,
            key=scores.get
        )


        confidence = scores[best]


        print(
            "DEBUG Intent Scores:",
            scores
        )


        print(
            "DEBUG Confidence:",
            confidence
        )


        if confidence == 0:

            return "knowledge"


        return best
