from brain.explanation_engine import ExplanationEngine
from brain.comparison_engine import ComparisonEngine


class Router:
    """
    CONNY AI Advanced Router

    The router is responsible for choosing
    which intelligence module should answer.
    """

    def __init__(self, brain):

        self.brain = brain

        self.explainer = ExplanationEngine()

        self.comparer = ComparisonEngine()


    def route(self, message, emotion=None):

        text = message.lower().strip()

        if emotion:

            print(
                "DEBUG User Emotion:",
                emotion
            )

        # ---------------------------------
        # Decision
        # ---------------------------------

        decision = self.brain.decision.choose(
            text
        )


        print(
            "DEBUG Decision:",
            decision
        )


        # ---------------------------------
        # Conversation
        # ---------------------------------

        if decision == "conversation":

            return self.handle_conversation(
                text
            )


        # ---------------------------------
        # Memory store
        # ---------------------------------

        if decision == "memory_store":

            return self.handle_memory_store(
                message
            )


        # ---------------------------------
        # Memory recall
        # ---------------------------------

        if decision == "memory_recall":

            return self.handle_memory_recall()



        # ---------------------------------
        # Comparison
        # ---------------------------------

        if decision == "comparison":

            return self.handle_comparison(
                message
            )



        # ---------------------------------
        # Calculator / Plugins
        # ---------------------------------

        if decision == "calculator":

            return self.handle_plugin(
                message
            )



        # ---------------------------------
        # Coding
        # ---------------------------------

        if decision == "coding":

            return self.handle_coding(
                message
            )



        # ---------------------------------
        # Creative
        # ---------------------------------

        if decision == "creative":

            return self.handle_creative(
                message
            )



        # ---------------------------------
        # Internet
        # ---------------------------------

        if decision == "internet":

            return self.handle_internet(
                message
            )



        # ---------------------------------
        # System
        # ---------------------------------

        if decision == "system":

            return self.handle_system(
                message
            )



        # ---------------------------------
        # Knowledge
        # ---------------------------------

        if decision == "knowledge":

            return self.handle_knowledge(
                message
            )



        return self.brain.response.unknown_response()



    # =================================
    # Conversation Handler
    # =================================

    def handle_conversation(self, text):

        responses = {

            "hi":
            "Hello Corneille! 👋 I am CONNY AI. How can I help you today?",

            "hello":
            "Hello! CONNY AI is ready.",

            "hey":
            "Hey Corneille! What are we building today?",

            "how are you":
            "I'm running well! My systems are ready.",

            "who are you":
            "I am CONNY AI, your personal artificial intelligence assistant.",

            "thank you":
            "You're welcome, Corneille.",

            "bye":
            "Goodbye Corneille. See you soon."

        }


        for key, value in responses.items():

            if key in text:

                return value


        return (
            "I'm here and ready to help."
        )



    # =================================
    # Memory
    # =================================

    def handle_memory_store(self, message):

        return self.brain.memory.remember(
            message
        )


    def handle_memory_recall(self):

        return self.brain.memory.show()



    # =================================
    # Comparison
    # =================================

    def handle_comparison(self, message):

        parts = (
            message.lower()
            .replace(" versus ", " vs ")
            .split(" vs ")
        )


        if len(parts) == 2:

            first = self.brain.knowledge.find_by_name(
                parts[0].strip()
            )

            second = self.brain.knowledge.find_by_name(
                parts[1].strip()
            )


            if first and second:

                return self.comparer.compare(
                    first,
                    second
                )


        return (
            "I need two things to compare."
        )



    # =================================
    # Knowledge
    # =================================

    def handle_knowledge(self, message):

        intent = self.brain.intent_engine.detect(
            message
        )


        concept = self.brain.knowledge.search(
            message
        )


        if concept:

            return self.explainer.generate(
                intent,
                concept
            )


        return (
            "I don't know that yet, but I can learn."
        )



    # =================================
    # Plugins
    # =================================

    def handle_plugin(self, message):

        plugin = self.brain.plugins.find_plugin(
            message
        )


        if plugin:

            return plugin.run(
                message
            )


        return (
            "I could not find a tool for that."
        )



    # =================================
    # Future AI modules
    # =================================

    def handle_coding(self, message):

        return (
            "Coding assistant module is ready for integration."
        )


    def handle_creative(self, message):

        return (
            "Creative assistant module is ready for integration."
        )


    def handle_internet(self, message):

        return (
            "Internet intelligence module is ready for integration."
        )


    def handle_system(self, message):

        return (
            "System control module is ready for integration."
        )
